#!/usr/bin/env python

import matplotlib.pyplot as plt
import numpy as np

from plotting import setup_plot, tableau20

# p_at_10 = [6.1, 6.1, 58.8, 54.2, 88.1, 80.3, 88.8]
p_at_10 = [4.9, 34.9, 60.7, 80.3]

labels = [
    r"\textsc{\small DETextPrior}", r"\textsc{\small DEVisionCNN}",
    r"{\small \sffamily{\textbf{XVisionSpeechCNN}}}", r"\textsc{\small XBoWCNN}"
    ]

setup_plot()

plt.rcParams["axes.titlesize"]          = "large"
plt.rcParams["legend.fontsize"]         = "medium"

plt.rcParams["figure.figsize"]          = 5, 2.5
plt.rcParams["figure.subplot.bottom"]   = 0.2
plt.rcParams["figure.subplot.left"]   = 0.28

spacing = 0
x_pos = np.concatenate(
    [np.arange(2), [2 + spacing] , 3 + 2*spacing + np.arange(1)]
    )
x_pos = x_pos[::-1]

plt.barh(x_pos[:2], p_at_10[:2], align="center", color=tableau20[15], lw=0, height=0.6)
plt.barh(x_pos[2:3], p_at_10[2:3], align="center", color=tableau20[2], lw=0, height=0.6)
# plt.barh(x_pos[3:], p_at_10[3:], align="center", color=tableau20[4], lw=0, height=0.6)
plt.yticks(x_pos, labels) #, rotation=90)

plt.xlabel(r"$P@10$ \textrm{(\%)}")
plt.xlim([0, 100])

# plt.savefig("p_at_10_dev-0.pdf")

# plt.barh(x_pos[2:3], p_at_10[2] + 8.2, align="center", color=tableau20[3], lw=0, height=0.6)
# plt.barh(x_pos[3:], p_at_10[3] + 11.5, align="center", color=tableau20[5], lw=0, height=0.6)
# plt.barh(x_pos[2:3], p_at_10[2:3], align="center", color=tableau20[2], lw=0, height=0.6)
# plt.barh(x_pos[3:], p_at_10[3:], align="center", color=tableau20[4], lw=0, height=0.6)
# plt.savefig("p_at_10_dev-1.pdf")

plt.barh(x_pos[2:3], p_at_10[2] + 8.2 + 22.1, align="center", color=tableau20[2], lw=0, height=0.6, label="semantic match")
plt.barh(x_pos[3:], p_at_10[3] + 11.5 + 3.3, align="center", color=tableau20[2], lw=0, height=0.6)
plt.barh(x_pos[2:3], p_at_10[2] + 8.2, align="center", color=tableau20[0], lw=0, height=0.6, label="exact match")
plt.barh(x_pos[3:], p_at_10[3] + 11.5, align="center", color=tableau20[0], lw=0, height=0.6) # , label="exact match (1)")
# plt.barh(x_pos[2:3], p_at_10[2:3], align="center", color=tableau20[6], lw=0, height=0.6, label="actual error")
plt.barh(x_pos[2:3], p_at_10[2:3], align="center", color=tableau20[4], lw=0, height=0.6)
plt.barh(x_pos[3:], p_at_10[3:], align="center", color=tableau20[15], lw=0, height=0.6)

plt.legend()

plt.savefig("p_at_10_dev-2.pdf")

# ap = [0.215, 0.222, 0.286, 0.469]
# labels = ["Autoencoder", "UBM-GMM", "TopUBM", "cAE"]

# # Example data
# # people = ('Tom', 'Dick', 'Harry', 'Slim', 'Jim')
# # performance = 3 + 10 * np.random.rand(len(people))
# # error = np.random.rand(len(people))

# setup_plot()
# plt.rcParams["figure.subplot.bottom"]   = 0.2
# x_pos = np.arange(len(labels))
# plt.bar(x_pos, ap, align="center", color=tableau20[0], lw=0, width=0.6)
# plt.xticks(x_pos, labels, rotation=40)

# # plt.grid()
# # plt.gca().set_axisbelow(True)
# plt.ylabel("Average precision")

# plt.savefig("ap.pdf")


# plt.show()


